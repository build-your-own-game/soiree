import {spawn} from 'node:child_process';import{once}from'node:events';import{writeFileSync}from'node:fs';
const results=[];
for(let index=0;index<5;index++){
 const child=spawn(process.execPath,['/tmp/rtc-product-cold-20261029.mjs'],{env:{...process.env,RTC_DIAGNOSTIC_CASE:String(index)},stdio:['ignore','pipe','pipe']});
 let output='';child.stdout.on('data',b=>output+=b);child.stderr.on('data',b=>output+=b);
 const [code,signal]=await once(child,'exit');results.push({index,code,signal,output});console.log(JSON.stringify(results.at(-1)));writeFileSync('/tmp/rtc-product-cold-driver-20261029.json',JSON.stringify(results,null,2));
}
if(results.some(r=>r.code!==0))process.exitCode=1;
