import {launchBrowser} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/browser.mjs';
import {Toxiproxy} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/toxiproxy.mjs';
import {welcomeDevice} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/udp.mjs';
import {verifyRtcNegotiation} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/rtc-negotiation.mjs';
import {cleanupAll} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/cleanup.mjs';
import{spawn}from'node:child_process';import{createServer}from'node:net';import{once}from'node:events';import{networkInterfaces}from'node:os';import{mkdtempSync,writeFileSync}from'node:fs';
const wait=ms=>new Promise(r=>setTimeout(r,ms));const lan=Object.values(networkInterfaces()).flat().find(a=>a?.family==='IPv4'&&!a.internal)?.address;
const reserve=createServer();reserve.listen(0);await once(reserve,'listening');const port=reserve.address().port;await new Promise(r=>reserve.close(r));
const cwd='/Users/axel2/Projects/build-your-own-game/games/punchline';const host=spawn('cargo',['run','--release','-p','punch-host'],{cwd,env:{...process.env,PUNCH_PORT:String(port),PUNCH_DATA:mkdtempSync('/tmp/rtc-sdk-new-'),SALON_LOG:'1'},stdio:['ignore','pipe','pipe']});
let output='';host.stdout.on('data',b=>{output+=b;process.stdout.write(b);});host.stderr.on('data',b=>{output+=b;process.stdout.write(b);});let browser,toxiproxy;const results=[];
try{
 const until=Date.now()+120000;while(!output.includes('Punchline ready')&&Date.now()<until){if(host.exitCode!==null)throw new Error(output);await wait(50);}if(!output.includes('Punchline ready'))throw new Error('host build deadline');
 browser=await launchBrowser();toxiproxy=await Toxiproxy.start();await browser.open(`http://localhost:${port}/?salon=ws`);const phones=[];
 for(const engine of ['webkit','chromium','webkit']){const proxy=await toxiproxy.proxy(lan,port),url=`http://127.0.0.1:${proxy.port}/play?salon=ws`;const tab=await browser.open(url,{mobile:true,engine});await tab.page.locator('#name').fill(`RTC${phones.length+1}`);await tab.page.locator('button.primary').click();const device=tab.wsReceived.map(row=>welcomeDevice(row.payload)).find(id=>id!==null);phones.push({tab,url,device,engine});}
 for(const phone of phones.slice(0,2)){
  const rows=[];results.push({engine:phone.engine,expectedDevice:phone.device,cases:rows});
  try{const report=await verifyRtcNegotiation({page:phone.tab.page,url:phone.url,upstream:lan,port,expectedDevice:phone.device,onCase:row=>{rows.push(row);console.log(JSON.stringify({engine:phone.engine,case:row.name,elapsed:row.elapsed_ms,rx:row.state.rtc?.received,ws:row.state.ws?.ws.length}));},onCleanupFailure:(error,primary)=>console.log(JSON.stringify({cleanup:error.message,primary:primary?.message}))});Object.assign(results.at(-1),report);}
  catch(error){results.at(-1).error=error.message;results.at(-1).receipt=error.rtcNegotiation;throw error;}
 }
}finally{
 const failures=await cleanupAll([{name:'browser',run:()=>browser?.close()},{name:'proxy',run:()=>toxiproxy?.stop()},{name:'host',run:async()=>{if(host.exitCode===null){host.kill('SIGTERM');await once(host,'exit');}}}]);writeFileSync('/tmp/rtc-negotiation-production-20261029.json',JSON.stringify({lan,port,results,output,cleanup:failures},null,2));if(failures.length)throw new Error(failures.join('; '));
}
