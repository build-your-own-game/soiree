import {launchBrowser} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/browser.mjs';
import {UdpProxy,observeRtc,rewrittenJsonFulfillment} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/udp.mjs';
import {Toxiproxy} from '/Users/axel2/Projects/build-your-own-game/soiree/tools/cert/toxiproxy.mjs';
import {spawn} from 'node:child_process';import {createServer} from 'node:net';import {once} from 'node:events';import {networkInterfaces} from 'node:os';import {writeFileSync,mkdtempSync,appendFileSync} from 'node:fs';
const wait=ms=>new Promise(r=>setTimeout(r,ms));const lan=Object.values(networkInterfaces()).flat().find(a=>a?.family==='IPv4'&&!a.internal)?.address;
const reserve=createServer();reserve.listen(0);await once(reserve,'listening');const port=reserve.address().port;await new Promise(r=>reserve.close(r));
const cwd='/Users/axel2/Projects/build-your-own-game/games/punchline',outputFile='/tmp/rtc-deadline-20261029.json';
const host=spawn(`${cwd}/target/release/punch-host`,['--no-build'],{cwd,env:{...process.env,PUNCH_PORT:String(port),PUNCH_DATA:mkdtempSync('/tmp/rtc-owned-repeat-'),SALON_LOG:'1'},stdio:['ignore','pipe','pipe']});
let output='';host.stdout.on('data',b=>output+=b);host.stderr.on('data',b=>output+=b);
let browser,toxiproxy,relay;const results=[],routes=[],network=[];
try{
 const deadline=Date.now()+5000;while(!output.includes('Punchline ready')&&Date.now()<deadline)await wait(25);if(!output.includes('Punchline ready'))throw new Error(output);
 browser=await launchBrowser();toxiproxy=await Toxiproxy.start();
 const tv=await browser.open(`http://localhost:${port}/?salon=ws`);const phones=[];
 for(const engine of ['webkit','chromium','webkit']){const proxy=await toxiproxy.proxy(lan,port),url=`http://127.0.0.1:${proxy.port}/play`;const tab=await browser.open(`${url}?salon=ws`,{mobile:true,engine});await tab.page.locator('#name').fill(`Probe${phones.length+1}`);await tab.page.locator('button.primary').click();phones.push({proxy,url,tab});}
 const phone=phones[0];await phone.tab.page.addInitScript(observeRtc);await phone.tab.page.addInitScript(()=>{const native=globalThis.setTimeout;globalThis.__rtcDeadline=[];globalThis.setTimeout=function(callback,ms,...args){const held=ms===3000&&new URL(location.href).searchParams.has('__holdRtcPatience');if(ms===3000)globalThis.__rtcDeadline.push({kind:'registered',at:Date.now(),held});return native(function(...values){if(ms===3000)globalThis.__rtcDeadline.push({kind:'fired',at:Date.now(),held});if(!held)return callback(...values);},ms,...args);};});relay=await UdpProxy.open(lan,port);
 phone.tab.page.on('console',message=>network.push({at:Date.now(),type:'console',level:message.type(),text:message.text()}));
 phone.tab.page.on('requestfailed',req=>network.push({at:Date.now(),type:'requestfailed',url:req.url(),failure:req.failure()}));
 let delayMs=0;await phone.tab.page.route('**/salon/offer',async route=>{const at=Date.now();try{const response=await route.fetch();const value=relay.rewrite(await response.json());routes.push({at,completed:Date.now(),status:response.status(),headers:response.headers(),sdp:value});await wait(delayMs);await route.fulfill(rewrittenJsonFulfillment(response,value));}catch(error){routes.push({at,error:error.message});await route.abort();}});
 const cases=[{delay:2000,hold:false},{delay:4000,hold:false},{delay:4000,hold:true},{delay:0,hold:false}];for(let attempt=0;attempt<cases.length;attempt++){delayMs=cases[attempt].delay;const sockets=phone.tab.sockets;
  const at=Date.now(),before=relay.snapshot(),logOffset=output.length,routeOffset=routes.length,networkOffset=network.length;
  await phone.tab.goto(phone.url+(cases[attempt].hold?'?__holdRtcPatience=1':''));
  await wait(Math.max(3400,delayMs+800));
  const trace=await phone.tab.evaluate('({rtc:globalThis.__certRtc,native:globalThis.__certRtc?.events,deadline:globalThis.__rtcDeadline,visibility:document.visibilityState,focus:document.hasFocus()})');
  const result={attempt,case:cases[attempt],socketsOpened:phone.tab.sockets-sockets,at,elapsed:Date.now()-at,trace,before,after:relay.snapshot(),routes:routes.slice(routeOffset),network:network.slice(networkOffset),host:output.slice(logOffset),errors:phone.tab.errors};results.push(result);appendFileSync('/tmp/rtc-deadline-20261029.ndjson',JSON.stringify(result)+'\n');console.log(JSON.stringify({attempt,received:trace.rtc?.received,sent:trace.rtc?.sent,events:trace.native?.map(e=>({type:e.kind,at:e.at,error:e.error,ice:e.ice,gathering:e.gathering,connection:e.connection})),routes:result.routes.map(r=>({at:r.at,completed:r.completed,error:r.error})),host:result.host}));
 }
}finally{
 if(relay)await relay.close();if(browser)await browser.close();if(toxiproxy)toxiproxy.stop();host.kill('SIGTERM');await once(host,'exit');writeFileSync(outputFile,JSON.stringify({lan,port,results,output},null,2));
}
if(!results[0]?.trace.rtc?.received||results[1]?.trace.rtc?.received||!results[2]?.trace.rtc?.received||!results[3]?.trace.rtc?.received)process.exitCode=1;
